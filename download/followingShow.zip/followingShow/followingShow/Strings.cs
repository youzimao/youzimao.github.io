﻿using System;
using System.Collections.Generic;
using System.Text;

namespace followingShow
{
   public  class Strings
    {


        private static string Api_Pre = "https://api.bilibili.com/x/relation/stat?vmid=";
        private static string Api_Suf = "&jsonp=jsonp";

        public  static  string FollowerUrl_Youzi = "https://api.bilibili.com/x/relation/stat?vmid=305196324&jsonp=jsonp";
        public  static  string FollowerUrl_Moyu = "https://api.bilibili.com/x/relation/stat?vmid=32747520&jsonp=jsonp";
        /// <summary>
        /// 视频信息api，使用bv号
        /// </summary>
        public static string VideoInfoApi = "https://api.bilibili.com/x/web-interface/view?bvid=";

        public static string FollowerUrl = "https://api.bilibili.com/x/relation/stat?vmid=305196324&jsonp=jsonp";
        public static void ChangeUid(string _uid)
        {
            FollowerUrl = Api_Pre + _uid + Api_Suf;
        }
    }
}
