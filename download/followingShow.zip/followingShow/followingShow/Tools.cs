﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;

namespace followingShow
{
    public  class Tools
    {
        /// <summary>
        /// 读取Uid.xml中的指定node
        /// </summary>
        /// <param name="nodeName">节点name</param>
        /// <returns></returns>
        public static string GetStrsFromXml(string fileName,string nodeName)
        {
            string str = string.Empty;
            string xmlPath = System.AppDomain.CurrentDomain.BaseDirectory + fileName;
            
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(xmlPath);
                XmlNodeList xmlNlist = xmlDoc.GetElementsByTagName(nodeName);

                if (xmlNlist.Count > 0)
                {
                    str = xmlNlist[0].InnerText;
                }

            }
            catch
            {
            }
            return str;
        }
        /// <summary>
        /// 修改Uid.xml中的指定node
        /// </summary>
        /// <param name="nodeName">节点name</param>
        /// <returns></returns>
        public static void SetStrsFromXml(string nodeName, string content)
        {
            string str = string.Empty;
            string xmlPath = System.AppDomain.CurrentDomain.BaseDirectory + "/Uid.xml";
            XmlDocument xmlDoc = new XmlDocument();
           // Trace.WriteLine(xmlPath);
            try
            {


                xmlDoc.Load(xmlPath);
                XmlNodeList xmlNlist = xmlDoc.GetElementsByTagName(nodeName);

                if (xmlNlist.Count > 0)
                {
                    xmlNlist[0].InnerText = content;
                }

            }
            catch
            {
            }
            xmlDoc.Save(xmlPath);
        }

        /// <summary>
        ///Http的get请求
        /// </summary>
        /// <param name="url">请求地址</param>
        /// <returns></returns>
        public static string Get(string url)
        {
            string result = "";
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
            Stream stream = resp.GetResponseStream();
            try
            {
                //获取内容
                using (StreamReader reader = new StreamReader(stream))
                {
                    result = reader.ReadToEnd();
                }
            }
            finally
            {
                stream.Close();
            }
            return result;
        }
    }
}
