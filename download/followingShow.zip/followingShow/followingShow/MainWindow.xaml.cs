﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Timers;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Media;

namespace followingShow
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Load;

          
            videoInfo.mainWindow = this;
            
        }
      private readonly VideoInfo videoInfo = new VideoInfo();

        /// <summary>
        /// 初始化videoInfo窗口、Uid和timer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainWindow_Load(object sender, RoutedEventArgs e)
        {
            Uid.Text = Tools.GetStrsFromXml("Uid.xml", "CurrentUid");
           
            if (Uid.Text.Length>0)
            {
                Strings.ChangeUid(Uid.Text);
            }
            videoInfo.Owner = this;
            videoInfo.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            myTimer = new System.Timers.Timer(1000);//定时周期2秒
            myTimer.Elapsed += UpdateCount;//
            myTimer.AutoReset = true; //是否不断重复定时器操作
            myTimer.Start();
        }

  
        System.Timers.Timer myTimer;

        private void ReFreshUI(string _value)
        {
            Action action = () => fansCount.Text = _value;
           
            Dispatcher.BeginInvoke(action);
        }
        
        private void UpdateCount(object sender, ElapsedEventArgs e)
        {
            // get: { "code":0,"message":"0","ttl":1,"data":{ "mid":32747520,"following":379,"whisper":0,"black":0,"follower":9} }

            try
            {
                string jsonText = Tools.Get(Strings.FollowerUrl);
                JObject jo = (JObject)JsonConvert.DeserializeObject(jsonText);
                ReFreshUI(jo["data"]["follower"].ToString());
            }
            catch (Exception)
            {

               
            }
          
            
        }


        //是否允许拖动
        private bool canDrag = true;

        /// <summary>
        /// 窗体拖动
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            //MARK  拖动
            if (!canDrag)
            {
                return;
            }

            // 获取鼠标相对标题栏位置  
            Point position = e.GetPosition(titleBar);

            // 如果鼠标位置在标题栏内，允许拖动  
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (position.X >= 0 && position.X < titleBar.ActualWidth && position.Y >= 0 && position.Y < titleBar.ActualHeight)
                {
                    this.DragMove();
                }
            }
        }
        private void CloseWindow_Click(object sender, RoutedEventArgs e)
        {
            videoInfo.Close();
            this.Close();
        }

        private void Lock_Click(object sender, RoutedEventArgs e)
        {
            // 锁定拖动，取消点击
            canDrag = !canDrag;
            if (canDrag)
            {
                if (!isTransparency)
                {
                    Topmost = false;
                }
                Lock.Background.Opacity = 1;
                LockImg.ImageSource = new BitmapImage(new Uri("D:/CsharpProject/wpfIcons/lock.png"));
            }
            else
            {
                
                Topmost = true;
                Lock.Background.Opacity = 0.4f;
                LockImg.ImageSource = new BitmapImage(new Uri("D:/CsharpProject/wpfIcons/unlock.png"));
            }
        }

        private void VideoInfo_Click(object sender, RoutedEventArgs e)
        {
            videoInfo.Left = this.Left;
            videoInfo.Top = this.Top;
            this.Hide();
            videoInfo.Show();
        }

  

        private void UidConfirm_Click(object sender, RoutedEventArgs e)
        {

            //TODO 保存uid
            if (Uid.Text.Length==0)
            {
                return;
            }
            Strings.ChangeUid(Uid.Text);
            Tools.SetStrsFromXml("CurrentUid",Uid.Text);
        }

        //是否为透明模式
        bool isTransparency = false;


        /// <summary>
        /// 透明模式，将一些Grid的background设置为透明
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void IsHit_Click(object sender, RoutedEventArgs e)
        {
            isTransparency = !isTransparency;
          //  Trace.WriteLine("透明");
            if (isTransparency)
            {
                Grid_3.Opacity = 0;
                Content_0.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00111111"));
                Content_1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00111111"));

                FanCountText.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                fansCount.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
             

                Topmost = true;
            }
            else
            {
                
                Content_0.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#5566ccff"));
                Content_1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#5500ffff"));

                FanCountText.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                fansCount.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));

                Grid_3.Opacity = 0.4f; 
                
            }
            
        }
    }
}
