﻿using LitJson;
using System;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace followingShow
{
    /// <summary>
    /// VideoInfo.xaml 的交互逻辑
    /// </summary>
    public partial class VideoInfo : Window
    {
      
        public VideoInfo()
        {
            InitializeComponent();

            this.Loaded += VideoInfo_Loaded;
        }

        private void VideoInfo_Loaded(object sender, RoutedEventArgs e)
        {
            
            BvNum.Text = Tools.GetStrsFromXml("Uid.xml","CurrentBv");
        }


        /// <summary>
        /// 计时器
        /// </summary>
        private System.Timers.Timer myTimer;
        void SetUpTimer()
        {

            myTimer = new System.Timers.Timer(2000);//定时周期2秒
            myTimer.Elapsed += ReFreshUI;//每隔两秒刷新一次ui
            myTimer.AutoReset = true; 
        }

        /// <summary>
        /// 更新UI
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ReFreshUI(object sender, ElapsedEventArgs e)
        {
            //开启一个异步线程，后台等待bilibili的Api发送get请求完成
            Info _value = await Task<Info>.Run(GetContent);
            Dispatcher.Invoke(() => { // coverPic = _value.CoverUrl;
                VideoTitle.Text = _value.Title;
                Author.Text = _value.Author;
                //UpDate.Text = _value.UpDate;
                PlayTimes.Text = _value.PlayTimes;
                Coins.Text = _value.Coins;
                Likes.Text = _value.Likes;
            });
        }

        private Info GetContent()
        {

            try
            {
                string jsonText = Tools.Get(Strings.VideoInfoApi + currentBv);
                JsonData jo = JsonMapper.ToObject(jsonText);
                Info _value = new Info()
                {
                    CoverUrl = jo["data"]["pic"].ToString(),
                    Title = jo["data"]["title"].ToString(),
                    Author = jo["data"]["owner"]["name"].ToString(),
                    // UpDate = "null",
                    Coins = jo["data"]["stat"]["coin"].ToString(),
                    Likes = jo["data"]["stat"]["like"].ToString(),
                    PlayTimes = jo["data"]["stat"]["view"].ToString()

                };
                return _value;
            }
            catch (Exception)
            {
                return null;
                throw;
            }

        }

        //当前的bv号
        private string currentBv = string.Empty;
        //是否允许拖动窗口
        private bool canDrag = true;
        /// <summary>
        /// 窗体拖动
        /// </summary>
        /// <param name="e"></param>
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            if (!canDrag)
            {
                return;
            }
            // 获取鼠标相对标题栏位置  
            Point position = e.GetPosition(titleBar);

            // 如果鼠标位置在标题栏内，允许拖动  
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (position.X >= 0 && position.X < titleBar.ActualWidth && position.Y >= 0 && position.Y < titleBar.ActualHeight)
                {
                    this.DragMove();
                }
            }
        }
        private void CloseWindow_Click(object sender, RoutedEventArgs e)
        {
            mainWindow.Close();
            this.Close();
        }

       // string coverPic=string.Empty;
       // string currentBv = string.Empty;
        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
           // Trace.WriteLine("asd");

            currentBv = BvNum.Text;
            if (currentBv == "")
            {
                return;
            }
            Tools.SetStrsFromXml("CurrentBv",currentBv);
            //TODO 开启一个线程去获取封面
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.DoWork += SetCover_DoWork;

            worker.RunWorkerCompleted += (object sender, RunWorkerCompletedEventArgs e) =>
            {

                Cover.Source = new BitmapImage(new Uri(e.Result.ToString()));

            };
            worker.RunWorkerAsync();

            //MARK 重置并启动timer
            SetUpTimer();
            myTimer.Start();

        }
        void SetCover_DoWork(object s, DoWorkEventArgs e)
        {
            // BackgroundWorker worker = s as BackgroundWorker;
            try
            {
                string jsonText = Tools.Get(Strings.VideoInfoApi + currentBv);
                JsonData jo = JsonMapper.ToObject(jsonText);

                string temp = jo["data"]["pic"].ToString();
                e.Result = temp;

               
            }
            catch (Exception)
            {
            }

        }

        private void Lock_Click(object sender, RoutedEventArgs e)
        {
            
            canDrag = !canDrag;
            if (canDrag)
            {
                
                Lock.Background.Opacity = 1;
                LockImg.ImageSource = new BitmapImage(new Uri("D:/CsharpProject/wpfIcons/lock.png"));
            }
            else
            {
                Lock.Background.Opacity = 0.4f;
                LockImg.ImageSource = new BitmapImage(new Uri("D:/CsharpProject/wpfIcons/unlock.png"));
            }
        }

        public MainWindow mainWindow;
        private void FansCount_Click(object sender, RoutedEventArgs e)
        {
            mainWindow.Left = this.Left;
            mainWindow.Top = this.Top;
            this.Hide();
            mainWindow.Show();
        }
    }

    public class Info
    {
        public string CoverUrl { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
      //  public string UpDate { get; set; }
        public string PlayTimes { get; set; }
        public string Coins { get; set; }
        public string Likes { get; set; }
    }
}
